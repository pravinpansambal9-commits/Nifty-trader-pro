NIFTY TRADER PRO - Android Studio Project

हा Android Studio प्रोजेक्ट तुमच्या HTML ट्रेडिंग कॅल्क्युलेटरला Android WebView App मध्ये उघडतो.

APK तयार करण्यासाठी:
1. ZIP extract करा.
2. Android Studio उघडा आणि 'Open' निवडून NiftyTraderPro फोल्डर निवडा.
3. Gradle Sync पूर्ण होऊ द्या. Android SDK Platform 35 आणि JDK 17 आवश्यक असू शकतात.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) निवडा.
5. APK तयार झाल्यावर Android Studio मधील 'locate' लिंकवर क्लिक करून app-debug.apk मिळवा.

टीप:
- या पॅकेजमध्ये APK नाही; हा APK तयार करण्यासाठीचा source project आहे.
- Android Studio/SDK वापरून Build करणे आवश्यक आहे.
- हा कॅल्क्युलेटर अंदाजे points-based P&L दाखवतो. प्रत्यक्ष option spread P&L, charges, slippage आणि market movement वेगळे असू शकतात.
- Lot size वापरण्यापूर्वी सध्याचा exchange/broker contract lot size तपासा.
